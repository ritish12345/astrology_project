async function getHoroscope() {
	try {
	  const url = 'https://best-daily-astrology-and-horoscope-api.p.rapidapi.com/api/Detailed-Horoscope/?zodiacSign=leo';
	  const options = {
		method: 'GET',
		headers: {
		  'X-RapidAPI-Key': '84e90eccb2msh8ae5797cf648da0p107426jsn9bd4196d18f9', // Replace with your actual key
		  'X-RapidAPI-Host': 'best-daily-astrology-and-horoscope-api.p.rapidapi.com'
		}
	  };
  
	  const response = await fetch(url, options);
	  const result = await response.text();
	  console.log(result);
	} catch (error) {
	  console.error(error);
	}
  }
  
  getHoroscope(); // Call the async function to execute the code
  